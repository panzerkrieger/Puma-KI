# Kirito Kun KI

Der Held aus Sword Art Online! Ein Einzelkämpfer mit einer unglaublichen Stärke und Geschwindigkeit. Er setzt sich für andere in Not ein und kämpft, um die fast 10.000 Spieler aus Aincrad zu befreien. Sein Glaube und Entschlossenheit, um sie zu befreien ist sein Größter Antrieb! Er gibt IMMER alles!

Viel Spaß beim Spielen!

Gibt viele Kämpfe mit Kirito auf meinem YouTube-Kanal [Xander10alpha](https://www.youtube.com/@Xander10alpha) schaut gerne vorbei!