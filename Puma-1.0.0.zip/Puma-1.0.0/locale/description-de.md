# Puma KI

Durch eine Freundin bekam er diesen Spitznamen. Amsonsten eine zwiegespaltene Persönlichkeit mit viel Potenzial. Kann er seine Depressionen erst überwinden wird er eine grosse Stärke entfalten ...

